const config = {
    dev_BaseUrl:process.env.REACT_APP_DEV_API_BASEURL,
    prod_BaseUrl:process.env.REACT_APP_PROD_API_BASEURL
}

export { config }